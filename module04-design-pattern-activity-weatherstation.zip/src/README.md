# CS4530 

## Task 6
The lines printed are in the same order if you subscribe all the displays in the same order.

## Task 7
Yes all the `XXXDisplay` should have the implementations because it creates a common contract among all of the Display classes. This makes the code to be more maintainable and allows you to add new Display classes more easily.
## Contact
Kunyang Li, li.kuny@northeastern.edu

Jae Wook Kim, kim.jaew@northeastern.edu

Dezeng Kong, kong.dez@northeastern.edu

Tracy Qiu, qiu.tr@northeastern.edu
